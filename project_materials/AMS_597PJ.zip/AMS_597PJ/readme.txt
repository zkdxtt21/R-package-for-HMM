

Test File: dhmm_test.R

Function File: dhmm_sim.R, dhmm_foward.R, dhmm_backward.R
               dhmm_estimate.R�� dhmm_viterbi.R
               dhmm_decoding.R
               
      
dhmm_infer.R is useless for now, we can delete it later.